package OrderManagementSystem;

public class Order {
	private String orderID;
    private String status;

    public void setStatus(String status) {
        this.status = status;
    }	
}
