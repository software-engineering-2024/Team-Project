package OrderManagementSystem;

public interface OrderObserver {
	void update(Order order);
}
