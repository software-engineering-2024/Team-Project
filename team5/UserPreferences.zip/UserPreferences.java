package UserPreferences;

public class UserPreferences {
	// 멤버 변수
	private String skinType;
	private double height;
	private double weight;
	private String favorFit;
	private String favorColor;
}
