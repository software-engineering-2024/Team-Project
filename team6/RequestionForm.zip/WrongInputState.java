package RequestionForm;

public class WrongInputState extends RequestionFormState{
	public void displayNotificationWindow() {}
}
