package RequestionForm;

public class NotInputState extends RequestionFormState{
	public void displayNotificationWindow() {};
}
