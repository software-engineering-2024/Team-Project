package RequestionForm;
import UserPreferences.UserPreferences;

public abstract class RequestionFormState {
	private UserPreferences userPreferences;
	
	public abstract void displayNotificationWindow();
}
