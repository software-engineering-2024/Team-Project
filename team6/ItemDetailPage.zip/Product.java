package ItemDetailPage;

public class Product {

}
