package ItemDetailPage;
public class ImageProxy extends LoadingImage{
	private Image mImage;
	
	public void getImage() {}
}
