package ItemDetailPage;

public class RealImage extends LoadingImage{
	private Image img;
	
	public void getImage() {}
}
