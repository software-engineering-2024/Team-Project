package ItemDetailPage;

public class ItemDetailPage {
	private Product item;
	private Image itemDetailImage;
	private double deliveryCharge;
	
	public ItemDetailPage openItemDetailPage(String itemID) {ItemDetailPage m = new ItemDetailPage(); return m;}
}
