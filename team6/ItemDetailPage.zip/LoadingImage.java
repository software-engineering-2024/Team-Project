package ItemDetailPage;

public class LoadingImage {
	public void getImage() {}
}
