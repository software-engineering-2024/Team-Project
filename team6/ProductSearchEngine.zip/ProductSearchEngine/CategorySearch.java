package ProductSearchEngine;
import java.util.*;
public class CategorySearch extends SearchStrategy{
	public List<Product> search(String category) {
        // 카테고리 검색 로직 (기본 구현)
        return new ArrayList<>();
    }
}
