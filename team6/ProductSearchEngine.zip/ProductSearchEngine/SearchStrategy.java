package ProductSearchEngine;
import java.util.*;
public abstract class SearchStrategy {
	public abstract List<Product> search(String parameter);
}
