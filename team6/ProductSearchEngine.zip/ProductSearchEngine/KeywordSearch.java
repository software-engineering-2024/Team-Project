package ProductSearchEngine;
import java.util.*;
public class KeywordSearch extends SearchStrategy{
	public List<Product> search(String keyword) {
        // 키워드 검색 로직 (기본 구현)
        return new ArrayList<>();
    }
}
