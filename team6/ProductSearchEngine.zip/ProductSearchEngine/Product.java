package ProductSearchEngine;

public class Product {

}
