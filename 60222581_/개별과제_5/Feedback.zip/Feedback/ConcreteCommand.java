public class ConcreteCommand implements Command {
    @Override
    public void execute() {
        // 기본 구현
    }
}
