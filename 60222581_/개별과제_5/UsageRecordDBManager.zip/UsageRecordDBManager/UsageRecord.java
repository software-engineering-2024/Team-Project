import java.util.Date;

// UsageRecord 클래스
public class UsageRecord {
    private String recordID;
    private String userID;
    private String itemID;
    private Date timestamp;
    private String action;
    
    public String getRecordDetails() {
        // 구현 내용
        return ""; // 예시를 위해 빈 문자열 반환
    }
}


